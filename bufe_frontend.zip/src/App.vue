<script setup>

</script>

<template>
  <div class="w-10 h-10 bg-slate-600">asd</div>
</template>

<style scoped>

</style>
